# route_data

route_data.tar.gz contains two files:
1) rib698k.v4.txt: 
   routes in this file is extracted from 5-hosts of route view project:
Host                                 File                       # IPv4 entries
route-views2.oregon-ix.net           rib.20160320.2200.bz2      630744
route-views.sydney.routeviews.org    rib.20160320.2000.bz2      602715
route-views.saopaulo.routeviews.org  rib.20160329.1600.bz2      613371
route-views.wide.routeviews.org      rib.20160630.2000.bz2      601203
route-views.linx.routeviews.org      rib.20160628.0200.bz2      618519
---------
Sum of different route                                          698608

2) rib1M.v4.txt
   routes in this file contains not only the previous data, but also the random generated new data,
all of these add up to over 1 million(1010680).

